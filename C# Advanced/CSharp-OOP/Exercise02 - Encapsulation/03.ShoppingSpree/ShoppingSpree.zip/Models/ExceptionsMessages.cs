﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.ShoppingSpree.Models
{
    public static class ExceptionsMessages
    {
        public const string NAME_CANNOT_BE_EMPTY = "Name cannot be empty";
        public const string MONEY_CANNOT_BE_NEGATIVE = "Money cannot be negative";
    }
}
