﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.ClassBoxData
{
    public static class ExceptionMessages
    {
        public const string PARAM_CANNOT_BE_ZERO_OT_NEGATIVE = "{0} cannot be zero or negative.";
    }
}
