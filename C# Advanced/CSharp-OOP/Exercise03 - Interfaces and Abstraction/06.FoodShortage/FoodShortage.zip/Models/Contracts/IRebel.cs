﻿namespace FoodShortage.Models.Contracts
{
    public interface IRebel : IPerson
    {
        public string Group { get; }
    }
}
