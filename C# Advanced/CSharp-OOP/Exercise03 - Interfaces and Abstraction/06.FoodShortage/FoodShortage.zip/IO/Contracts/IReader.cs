﻿
namespace FoodShortage.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
