﻿namespace _03.Telephony.Models.Contracts
{
    public interface IStationaryPhone
    {
        string Call(string phoneNumber);
    }
}
