﻿namespace _03.Telephony.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
