﻿namespace BorderControl.Models.Contracts
{
    public interface ICitizen : IRobot
    {
        public int Age { get; }
    }
}
