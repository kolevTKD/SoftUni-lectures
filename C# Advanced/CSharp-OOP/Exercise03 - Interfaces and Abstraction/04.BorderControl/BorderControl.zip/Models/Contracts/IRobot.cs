﻿namespace BorderControl.Models.Contracts
{
    public interface IRobot
    {
        public string Name { get; }
        public string Id { get; }
    }
}
