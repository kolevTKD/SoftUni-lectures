﻿namespace BirthdayCelebrations.Models.Contracts
{
    public interface IRobot
    {
        public string Model { get; }
    }
}
