﻿namespace BirthdayCelebrations.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
