﻿namespace VehiclesExtension.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
