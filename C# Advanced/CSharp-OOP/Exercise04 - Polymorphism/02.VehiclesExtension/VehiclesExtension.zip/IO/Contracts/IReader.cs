﻿namespace VehiclesExtension.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
