﻿namespace WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public const string FOOD_NOT_EATEN_EXCEPTION_MESSAGE = "{0} does not eat {1}!";
    }
}
