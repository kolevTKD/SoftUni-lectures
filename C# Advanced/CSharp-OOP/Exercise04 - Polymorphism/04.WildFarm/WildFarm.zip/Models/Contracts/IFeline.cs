﻿namespace WildFarm.Models.Contracts
{
    public interface IFeline : IMammal
    {
        string Breed { get; }
    }
}
