﻿namespace Vehicles.Exceptions
{
    public static class ExceptionMessages
    {
        public const string INSUFFICIENT_FUEL = "{0} needs refueling";
    }
}
