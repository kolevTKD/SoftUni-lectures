﻿namespace Vehicles.Exceptions
{

    public static class ExceptionMessages
    {
        public const string NEEDS_REFUELING = "{0} needs refueling";
    }
}
