﻿namespace WildFarm.Models.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
