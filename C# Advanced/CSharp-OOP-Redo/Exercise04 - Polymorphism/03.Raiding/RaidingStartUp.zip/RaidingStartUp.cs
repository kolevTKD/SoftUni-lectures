﻿using Raiding.Core;
using Raiding.Core.Contracts;
using Raiding.Factories;
using Raiding.Factories.Contracts;
using Raiding.IO;
using Raiding.IO.Contracts;

namespace Raiding
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();
            IHeroFactory herofactory = new HeroFactory();

            IEngine engine = new Engine(reader, writer, herofactory);
            engine.Run();
        }
    }
}
