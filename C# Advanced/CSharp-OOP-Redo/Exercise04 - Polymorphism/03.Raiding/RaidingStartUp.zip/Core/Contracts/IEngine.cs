﻿namespace Raiding.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
