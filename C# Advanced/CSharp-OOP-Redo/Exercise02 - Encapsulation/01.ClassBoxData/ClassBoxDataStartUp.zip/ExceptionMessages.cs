﻿namespace _01.ClassBoxData
{
    public static class ExceptionMessages
    {
        public const string PARAM_CANNOT_BE_ZERO_OR_NEGATIVE = "{0} cannot be zero or negative.";
    }
}
