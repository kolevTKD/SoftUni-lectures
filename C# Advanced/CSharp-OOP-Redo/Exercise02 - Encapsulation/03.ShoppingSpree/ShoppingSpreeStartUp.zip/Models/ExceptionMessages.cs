﻿namespace _03.ShoppingSpree.Models
{
    public static class ExceptionMessages
    {
        public const string NAME_CANNOT_BE_EMPTY = "Name cannot be empty";
        public const string MONEY_CANNOT_BE_NEGATIVE = "Money cannot be negative";
    }
}
