﻿namespace Telephony.Models.Contracts
{
    public interface IStationaryPhone
    {
        string CallNumber(string phoneNumber);
    }
}
