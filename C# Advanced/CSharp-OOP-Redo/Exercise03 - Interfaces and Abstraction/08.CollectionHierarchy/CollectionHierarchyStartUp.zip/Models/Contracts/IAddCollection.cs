﻿namespace CollectionHierarchy.Models.Contracts
{
    public interface IAddCollection<T>
    {
        int Add(T element);
    }
}
