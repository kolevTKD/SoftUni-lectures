﻿namespace FoodShortage.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
