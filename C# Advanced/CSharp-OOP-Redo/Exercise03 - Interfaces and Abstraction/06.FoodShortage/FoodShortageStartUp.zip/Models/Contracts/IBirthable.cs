﻿namespace FoodShortage.Models.Contracts
{
    public interface IBirthable
    {
        string BirthDate { get; }
    }
}
