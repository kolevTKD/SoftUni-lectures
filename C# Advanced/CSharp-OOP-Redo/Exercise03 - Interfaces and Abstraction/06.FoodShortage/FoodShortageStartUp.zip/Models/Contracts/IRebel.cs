﻿namespace FoodShortage.Models.Contracts
{
    public interface IRebel
    {
        string Group { get; }
    }
}
