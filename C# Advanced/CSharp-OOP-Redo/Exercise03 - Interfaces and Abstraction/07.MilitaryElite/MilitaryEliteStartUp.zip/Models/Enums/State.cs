﻿namespace MilitaryElite.Models.Enums
{
    public enum State
    {
        inProgress = 0,
        Finished = 1,
    }
}
