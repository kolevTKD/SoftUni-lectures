﻿namespace BirthdayCelebrations.Models.Contracts
{
    public interface IRobot : IIdentifiable
    {
        string Model { get; }
    }
}
