﻿namespace P01_HospitalDatabase.Data.Common
{
    public static class Config
    {
        public const string CONNECTION_STRING = "Server=localhost;Database=HospitalDatabase;Trusted_Connection=True;Trust Server Certificate=true;";
    }
}