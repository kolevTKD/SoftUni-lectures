﻿namespace P03_SalesDatabase.Data.Common
{
    public static class Config
    {
        public const string CONNECTION_STRING = "Server=localhost;Database=SalesDatabase;Trusted_Connection=True;Trust Server Certificate=true;";
    }
}