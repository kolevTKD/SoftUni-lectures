﻿namespace CarDealer.DTOs.Export
{
	public class ExportPartInfoDto
	{
		public string Name { get; set; } = null!;
		public string Price { get; set; } = null!;
	}
}
