﻿namespace P01_StudentSystem.Data.Common
{
    public static class Config
    {
        public const string CONNECTION_STRING = @"Server=localhost;Database=StudentSystem;Trusted_Connection=True;Trust Server Certificate=true;";
    }
}
