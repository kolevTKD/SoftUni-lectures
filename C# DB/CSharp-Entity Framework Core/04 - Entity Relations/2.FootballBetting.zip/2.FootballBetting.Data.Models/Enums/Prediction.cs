﻿namespace Enums
{
    public enum Prediction
    {
        Draw = 0,
        Win = 1,
        Loss = 2
    }
}
