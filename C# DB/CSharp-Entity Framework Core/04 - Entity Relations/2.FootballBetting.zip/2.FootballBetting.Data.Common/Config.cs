﻿namespace P02_FootballBetting.Data .Common
{
    public static class Config
    {
        public const string CONNECTION_STRING = "Server=localhost;Database=FootballBetting;Trusted_Connection=True;Trust Server Certificate=true;";
    }
}