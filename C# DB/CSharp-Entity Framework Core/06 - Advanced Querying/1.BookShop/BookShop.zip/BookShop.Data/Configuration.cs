﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=localhost;Database=BookShop;Trusted_Connection=True;Trust Server Certificate=true;";
    }
}
