﻿namespace MiniORM
{
    public class DbContext
    {
        // TODO: Create your DbContext class here.
    }
}
