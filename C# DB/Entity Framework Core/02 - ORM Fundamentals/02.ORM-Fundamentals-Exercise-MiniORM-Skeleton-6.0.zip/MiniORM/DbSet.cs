﻿namespace MiniORM
{
    public class DbSet
    {
        // TODO: Create your DbSet class here.
    }
}
