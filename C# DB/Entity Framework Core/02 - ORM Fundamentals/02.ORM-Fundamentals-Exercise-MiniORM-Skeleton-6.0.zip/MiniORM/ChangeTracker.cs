﻿namespace MiniORM
{
    public class ChangeTracker
    {
        // TODO: Create your ChangeTracker class here.
    }
}